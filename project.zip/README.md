# Painel Financeiro

## Como compilar este projeto

### Requisitos
- Android Studio (versão mais recente)
- JDK 11 ou superior

### Passos

1. **Abra o Android Studio**
2. **File > Open** e selecione a pasta extraída do ZIP
3. Aguarde o Gradle sincronizar o projeto
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)**

O APK será gerado em: `app/build/outputs/apk/debug/app-debug.apk`

### Para gerar AAB (Play Store)
1. **Build > Generate Signed Bundle / APK**
2. Selecione "Android App Bundle"
3. Crie ou use uma keystore existente
4. O AAB será gerado em: `app/release/`

## Estrutura do Projeto
- `app/src/main/assets/index.html` - Seu conteúdo HTML
- `app/src/main/java/com/app/painelfinanceiro/MainActivity.java` - Activity principal com WebView
